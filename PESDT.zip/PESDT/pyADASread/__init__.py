#print("\n-------------------- Loading pyADASread -----------------\n")

